gunakan
-npm install

agar dapat menjalankan project