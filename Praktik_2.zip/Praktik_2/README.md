jalankan 
-npm install && npx vite

untuk menjalankan project

[Note]:
jika project tidak dapat di jalankan coba ganti nama folder (Praktik#2) menjadi yang lain (coba hilangkan symbol dan juga nomor)